package com.example.studyroom;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.common.ChangeEventType;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class PostAdapter extends FirebaseRecyclerAdapter<Texts, PostAdapter.PostViewHolder> {
    Context mContext;
    private ClickListener mClickListener;

    public interface ClickListener {
        void onItemClick(View v,Texts texts, int position);
        void editButtonClick(String postId, Texts texts, int position);
        void deleteButtonClick(String postId, Texts texts, int position);
    }
    public void setClickListener(ClickListener listener){
        mClickListener =listener;
    }
    public PostAdapter(FirebaseRecyclerOptions<Texts> options){
        super(options,true);
    }

    @NonNull
    @Override
    public PostViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.listview_activity,parent,false);
        mContext = parent.getContext();
        return new PostViewHolder(view);
    }

    @Override
    protected void onBindViewHolder(final PostViewHolder holder, final int position, final Texts model) {
        holder.setPostTitle(model.getPostTitle());
        holder.setPostText(model.getPostText());
        //final String postId = this.getSnapshots().getSnapshot(position).getKey();
        holder.root.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mClickListener.onItemClick(v,model,position);
            }
        });

        if(MainBoard.currentUser.equals(model.getUserId())){
            holder.editBtn.setVisibility(View.VISIBLE);
            holder.bind(model);
            holder.deleteBtn.setVisibility(View.VISIBLE);
        }else {
            holder.editBtn.setVisibility(View.INVISIBLE);
            holder.deleteBtn.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    protected void onChildUpdate(Texts model, ChangeEventType type, DataSnapshot snapshot, int newIndex, int oldIndex) {
        model.setPostId(snapshot.getKey());
        super.onChildUpdate(model, type, snapshot, newIndex, oldIndex);
    }

    @Override
    protected boolean filterCondition(Texts model, String filterPattern) {
        return model.getPostTitle().toLowerCase().contains(filterPattern) || model.getPostText().toLowerCase().contains(filterPattern);
    }


    class PostViewHolder extends RecyclerView.ViewHolder {
        public LinearLayout root;
        public TextView postTitle;
        public TextView postText;
        ImageButton editBtn,deleteBtn;


        public PostViewHolder(View itemView){
            super(itemView);

            root = itemView.findViewById(R.id.rootLayout);
            postTitle = itemView.findViewById(R.id.threadTitle);
            postText = itemView.findViewById(R.id.threadText);
            editBtn = itemView.findViewById(R.id.editBtn);
            deleteBtn = itemView.findViewById(R.id.deleteBtn);


        }
        public void bind(final Texts model){
            editBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mClickListener.editButtonClick(model.getPostId(),model,getAdapterPosition());
                }
            });
            deleteBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int pos = getAdapterPosition();
                    Texts model = getItem(pos);
                    mClickListener.deleteButtonClick(model.getPostId(),model,pos);
                }
            });
        }


        public void setPostTitle(String title){
            postTitle.setText(title);
        }
        public void setPostText(String text){ postText.setText(text);}
    }
}